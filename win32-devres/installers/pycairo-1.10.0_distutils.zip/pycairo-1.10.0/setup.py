import os
import buildutils
from distutils.core import Extension

NAME = 'pycairo'
VERSION = '1.10.0'

src_path = 'src'
include_path = '../include'
lib_path = ['../libs']

cairo_src = os.path.join(src_path, 'cairo')
files = buildutils.make_source_list(cairo_src, ['cairomodule.c', 'context.c', 'font.c', 'matrix.c', 'path.c', 'pattern.c', 'surface.c', ])
include_dirs = buildutils.make_source_list(include_path, ['cairo', ])
cairo_module = Extension('cairo._cairo',
		define_macros=[('MAJOR_VERSION', '1'), ('MINOR_VERSION', '10')],
		sources=files, include_dirs=include_dirs,
		library_dirs=lib_path,
		libraries=['cairo'])

from distutils.core import setup


setup(name=NAME,
	version=VERSION,
	packages=['cairo'],
	package_dir={'cairo':'src/cairo', },
	package_data={},
	ext_modules=[cairo_module, ])

buildutils.compile_sources()
